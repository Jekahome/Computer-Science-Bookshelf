library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity UART is
    port (
        clk_i      : in  std_logic;
        rst_i      : in  std_logic;
        tx_data_i  : in  std_logic_vector(7 downto 0);
        transmit_i : in  std_logic;
        busy_o     : out std_logic;
        rx_data_o  : out std_logic_vector(7 downto 0);
        ready_o    : out std_logic;
        rx_i       : in  std_logic;
        tx_o       : out std_logic
    );
end UART;

architecture Behavioral of UART is
    -- Hardcoded values (50MHz / 115200) to clear the ports for Digital parser
    constant BIT_PERIOD : integer := 434; 
    constant HALF_BIT   : integer := 217;

    signal tx_state   : integer range 0 to 3 := 0;
    signal tx_counter : integer := 0;
    signal tx_bit_idx : integer range 0 to 7 := 0;
    signal tx_data    : std_logic_vector(7 downto 0) := (others => '0');
    signal tx_busy    : std_logic := '0';
    
    signal rx_state   : integer range 0 to 3 := 0;
    signal rx_counter : integer := 0;
    signal rx_bit_idx : integer range 0 to 7 := 0;
    signal rx_data    : std_logic_vector(7 downto 0) := (others => '0');
    signal rx_ready   : std_logic := '0';
    signal rx_sync    : std_logic := '1';
begin
    busy_o <= tx_busy;
    ready_o <= rx_ready;

    process(clk_i, rst_i)
    begin
        if rst_i = '1' then
            tx_o <= '1';
            tx_busy <= '0';
            tx_state <= 0;
            tx_counter <= 0;
            tx_bit_idx <= 0;
            tx_data <= (others => '0');
        elsif rising_edge(clk_i) then
            case tx_state is
                when 0 => 
                    tx_o <= '1';
                    tx_busy <= '0';
                    if transmit_i = '1' then
                        tx_data <= tx_data_i;
                        tx_busy <= '1';
                        tx_state <= 1;
                        tx_counter <= 0;
                    end if;

                when 1 => 
                    tx_o <= '0';
                    if tx_counter = BIT_PERIOD - 1 then
                        tx_state <= 2;
                        tx_counter <= 0;
                        tx_bit_idx <= 0;
                    else
                        tx_counter <= tx_counter + 1;
                    end if;

                when 2 => 
                    tx_o <= tx_data(tx_bit_idx);
                    if tx_counter = BIT_PERIOD - 1 then
                        if tx_bit_idx = 7 then
                            tx_state <= 3;
                            tx_counter <= 0;
                        else
                            tx_bit_idx <= tx_bit_idx + 1;
                            tx_counter <= 0;
                        end if;
                    else
                        tx_counter <= tx_counter + 1;
                    end if;

                when 3 => 
                    tx_o <= '1';
                    if tx_counter = BIT_PERIOD - 1 then
                        tx_state <= 0;
                        tx_busy <= '0';
                        tx_counter <= 0;
                    else
                        tx_counter <= tx_counter + 1;
                    end if;
                    
                when others =>
                    tx_state <= 0;
            end case;
        end if;
    end process;

    process(clk_i, rst_i)
    begin
        if rst_i = '1' then
            rx_state <= 0;
            rx_ready <= '0';
            rx_counter <= 0;
            rx_bit_idx <= 0;
            rx_sync <= '1';
            rx_data <= (others => '0');
            rx_data_o <= (others => '0');
        elsif rising_edge(clk_i) then
            rx_sync <= rx_i;
            
            case rx_state is
                when 0 => 
                    rx_ready <= '0';
                    if rx_sync = '0' then
                        rx_state <= 1;
                        rx_counter <= 0;
                    end if;

                when 1 => 
                    if rx_counter = HALF_BIT - 1 then
                        rx_state <= 2;
                        rx_counter <= 0;
                        rx_bit_idx <= 0;
                    else
                        rx_counter <= rx_counter + 1;
                    end if;

                when 2 => 
                    if rx_counter = BIT_PERIOD - 1 then
                        rx_data <= rx_sync & rx_data(7 downto 1);
                        if rx_bit_idx = 7 then
                            rx_state <= 3;
                            rx_counter <= 0;
                        else
                            rx_bit_idx <= rx_bit_idx + 1;
                            rx_counter <= 0;
                        end if;
                    else
                        rx_counter <= rx_counter + 1;
                    end if;

                when 3 => 
                    if rx_counter = BIT_PERIOD - 1 then
                        if rx_sync = '1' then
                            rx_data_o <= rx_data;
                            rx_ready <= '1';
                        end if;
                        rx_state <= 0;
                        rx_counter <= 0;
                    else
                        rx_counter <= rx_counter + 1;
                    end if;
                    
                when others =>
                    rx_state <= 0;
            end case;
        end if;
    end process;

end Behavioral;
